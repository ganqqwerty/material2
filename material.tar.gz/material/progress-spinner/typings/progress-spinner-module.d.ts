declare class MatProgressSpinnerModule {
}
export { MatProgressSpinnerModule };
