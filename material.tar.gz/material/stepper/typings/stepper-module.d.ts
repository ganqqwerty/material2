export declare class MatStepperModule {
}
