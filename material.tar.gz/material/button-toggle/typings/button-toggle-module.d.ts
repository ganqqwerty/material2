export declare class MatButtonToggleModule {
}
