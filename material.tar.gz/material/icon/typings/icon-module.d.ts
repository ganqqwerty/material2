export declare class MatIconModule {
}
