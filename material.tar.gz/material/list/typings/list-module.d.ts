export declare class MatListModule {
}
