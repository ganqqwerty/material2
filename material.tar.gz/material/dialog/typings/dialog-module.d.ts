export declare class MatDialogModule {
}
