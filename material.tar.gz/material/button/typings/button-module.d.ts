export declare class MatButtonModule {
}
