export declare class MatPaginatorModule {
}
