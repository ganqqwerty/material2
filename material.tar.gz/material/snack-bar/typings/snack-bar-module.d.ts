export declare class MatSnackBarModule {
}
