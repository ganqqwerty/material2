/** Single error message to be shown underneath the form field. */
export declare class MatError {
    id: string;
}
