/** The floating label for a `mat-form-field`. */
export declare class MatLabel {
}
