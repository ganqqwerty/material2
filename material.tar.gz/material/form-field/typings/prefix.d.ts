/** Prefix to be placed the the front of the form field. */
export declare class MatPrefix {
}
