/** The placeholder text for an `MatFormField`. */
export declare class MatPlaceholder {
}
