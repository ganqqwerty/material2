/** Suffix to be placed at the end of the form field. */
export declare class MatSuffix {
}
