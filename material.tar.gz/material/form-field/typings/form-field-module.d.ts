export declare class MatFormFieldModule {
}
