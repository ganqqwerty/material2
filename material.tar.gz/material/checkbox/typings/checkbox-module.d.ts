export declare class MatCheckboxModule {
}
