export declare class MatMenuModule {
}
