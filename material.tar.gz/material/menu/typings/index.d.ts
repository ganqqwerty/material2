/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { MatMenuItemBase as ɵa21, _MatMenuItemMixinBase as ɵb21 } from './menu-item';
export { MAT_MENU_SCROLL_STRATEGY_PROVIDER as ɵd21, MAT_MENU_SCROLL_STRATEGY_PROVIDER_FACTORY as ɵc21 } from './menu-trigger';
