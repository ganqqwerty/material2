export declare class MatToolbarModule {
}
