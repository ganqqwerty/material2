export declare class MatGridListModule {
}
