export declare class MatExpansionModule {
}
