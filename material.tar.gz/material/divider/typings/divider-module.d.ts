export declare class MatDividerModule {
}
