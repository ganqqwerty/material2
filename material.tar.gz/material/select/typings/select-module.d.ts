export declare class MatSelectModule {
}
