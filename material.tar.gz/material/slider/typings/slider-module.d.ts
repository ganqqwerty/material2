export declare class MatSliderModule {
}
