export declare class MatTableModule {
}
