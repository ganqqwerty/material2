import { CdkTable } from '@angular/cdk/table';
/**
 * Wrapper for the CdkTable with Material design styles.
 */
export declare class MatTable<T> extends CdkTable<T> {
}
