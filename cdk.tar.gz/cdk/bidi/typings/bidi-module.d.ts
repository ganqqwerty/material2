export declare class BidiModule {
}
