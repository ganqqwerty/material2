export declare class CdkTableModule {
}
